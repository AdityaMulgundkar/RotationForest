'''pymavlink code generator'''
